let animationData = [];
let currentFrame = 0;
let isPlaying = true;
const frameDuration = 100;

const canvas = document.getElementById('skeletonCanvas');
const ctx = canvas.getContext('2d');

const frameCountDisplay = document.getElementById("frameCount");
const currentFrameDisplay = document.getElementById("currentFrame");

const bones = [
  ["Left_Shoulder", "Right_Shoulder"],
  ["Left_Shoulder", "Left_Elbow"],
  ["Left_Elbow", "Left_Wrist"],
  ["Right_Shoulder", "Right_Elbow"],
  ["Right_Elbow", "Right_Wrist"],
  ["Left_Shoulder", "Left_Hip"],
  ["Right_Shoulder", "Right_Hip"],
  ["Left_Hip", "Right_Hip"],
  ["Left_Hip", "Left_Knee"],
  ["Left_Knee", "Left_Ankle"],
  ["Right_Hip", "Right_Knee"],
  ["Right_Knee", "Right_Ankle"]
];

// Original resolution of keypoint data
const originalWidth = 1280;
const originalHeight = 720;

function resizeCanvas() {
  const parent = canvas.parentElement;
  canvas.width = parent.offsetWidth;
  canvas.height = parent.offsetHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

async function loadAnimationData() {
  try {
    const response = await fetch('animation_data.json');
    animationData = await response.json();
    frameCountDisplay.textContent = animationData.length;
    requestAnimationFrame(animateFrame);
  } catch (error) {
    console.error("Failed to load animation data:", error);
  }
}

function animateFrame() {
  if (!isPlaying || animationData.length === 0) return;

  resizeCanvas();

  const keypoints = animationData[currentFrame].keypoints;
  const positions = {};

  const canvasWidth = canvas.width;
  const canvasHeight = canvas.height;

  const scaleX = canvasWidth / originalWidth;
  const scaleY = canvasHeight / originalHeight;

  const aspectRatio = originalWidth / originalHeight;
  const canvasAspect = canvasWidth / canvasHeight;

  let scale, offsetX = 0, offsetY = 0;

  if (canvasAspect > aspectRatio) {
    scale = canvasHeight / originalHeight;
    offsetX = (canvasWidth - originalWidth * scale) / 2;
  } else {
    scale = canvasWidth / originalWidth;
    offsetY = (canvasHeight - originalHeight * scale) / 2;
  }

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 10;

  for (const joint in keypoints) {
    if (!joint.endsWith("_X")) continue;

    const jointBase = joint.replace("_X", "");
    const x = keypoints[`${jointBase}_X`];
    const y = keypoints[`${jointBase}_Y`];

    const scaledX = offsetX + x * scale;
    const scaledY = offsetY + y * scale;

    positions[jointBase] = { x: scaledX, y: scaledY };

    const el = document.getElementById(jointBase);
    if (el) {
      el.style.left = `${scaledX}px`;
      el.style.top = `${scaledY}px`;
    }
  }

  for (const [a, b] of bones) {
    if (positions[a] && positions[b]) {
      ctx.beginPath();
      ctx.moveTo(positions[a].x, positions[a].y);
      ctx.lineTo(positions[b].x, positions[b].y);
      ctx.stroke();
    }
  }

  currentFrame = (currentFrame + 1) % animationData.length;
  currentFrameDisplay.textContent = currentFrame;

  setTimeout(() => requestAnimationFrame(animateFrame), frameDuration);
}

document.getElementById('playBtn').addEventListener('click', () => {
  if (!isPlaying) {
    isPlaying = true;
    requestAnimationFrame(animateFrame);
  }
});

document.getElementById('pauseBtn').addEventListener('click', () => {
  isPlaying = false;
});

loadAnimationData();
